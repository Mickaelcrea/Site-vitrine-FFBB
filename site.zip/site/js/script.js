
WebFont.load({
    google: {
        families: ["Jost:regular,500,600,700,800,900"]
    }
});

(function (window, document) {
    var htmlElement = document.documentElement;
    var className = " w-mod-";
    htmlElement.className += className + "js";
    if ("ontouchstart" in window || (window.DocumentTouch && document instanceof DocumentTouch)) {
        htmlElement.className += className + "touch";
    }
})(window, document);

document.addEventListener("DOMContentLoaded", function () {
    var navbar = document.querySelector('.navbar');
    if (navbar) {
    }
});
